語彙アプリ用 オリジナル音源セット

収録ファイル
- bgm_play_retro_loop.wav      プレイ中ループBGM（レトロゲーム風）
- bgm_result_victory.wav       リザルト画面BGM（高揚感のある勝利風）
- sfx_correct.wav              正解音
- sfx_wrong.wav                不正解音
- sfx_count_3.wav              3
- sfx_count_2.wav              2
- sfx_count_1.wav              1
- sfx_count_go.wav             GO

メモ
- すべてこの会話用のオリジナル音です。
- 特定楽曲のコピーではなく、雰囲気だけ近い方向にしています。
- 形式は .wav です。ブラウザでそのまま使えます。
